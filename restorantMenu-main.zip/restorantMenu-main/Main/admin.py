from django.contrib import admin
from . import models

admin.site.register(models.Kategori)
admin.site.register(models.KategoriÖgeleri)
admin.site.register(models.website) 
admin.site.register(models.sosyalmedya)