from django.db import models

class Kategori(models.Model):
    baslik = models.CharField(verbose_name='Kategori Başlığı', max_length=300)
    
    
    def __str__(self):
        return self.baslik
    
class KategoriÖgeleri(models.Model):
    baslik = models.CharField(verbose_name='Başlık', max_length=300)
    fiyat = models.IntegerField(verbose_name='Fiyat')
    image = models.ImageField(upload_to='images/', verbose_name="Ürün resmi", default="", null=True, blank=True)  
    
    kategori = models.ForeignKey(Kategori, on_delete=models.CASCADE, default="")
    def __str__(self) -> str:
        return self.baslik

class website(models.Model):
    logo = models.FileField(verbose_name="logonuzu giriniz ")
    ikincilogo = models.FileField(verbose_name="ikinci logonuzu giriniz ")
    anagorsel = models.FileField(verbose_name="sitede gözükmesini istediğiniz görseli giriniz ")
    footermetin = models.CharField(max_length=300, verbose_name="sitenizin açıklamasını giriniz")
    restaurantadi = models.CharField(max_length=300, verbose_name="restaurant adını giriniz")
    copyriht = models.CharField(max_length=300, verbose_name="copyright açıklamasını giriniz")

class sosyalmedya(models.Model):
    instagram = models.CharField(max_length=300, verbose_name="instagram hesap profilini giriniz")
    x = models.CharField(max_length=300, verbose_name="x hesap profilini giriniz")
    youtube= models.CharField(max_length=300, verbose_name="youtube hesap profilini giriniz")
    facebook = models.CharField(max_length=300, verbose_name="facebook hesap profilini giriniz")