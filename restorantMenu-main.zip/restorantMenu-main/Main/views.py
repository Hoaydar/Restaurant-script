from django.shortcuts import render
from . import models

# Create your views here.
def index(request):
    query = models.Kategori.objects.all()
    kategoriogeleri = models.KategoriÖgeleri.objects.all()
    website = models.website.objects.all()
    sosyalmedya = models.sosyalmedya.objects.all()
    return render(request=request,template_name='index.html', context={
        'query':query,
        'kategoriogeleri':kategoriogeleri,
        'website':website,
        'sosyalmedya':sosyalmedya,
    })