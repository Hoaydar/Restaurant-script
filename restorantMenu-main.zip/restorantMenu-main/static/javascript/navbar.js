const mobilMenu = document.getElementById('mobilMenu');
const button    = document.getElementById('mobilButton');

button.addEventListener('click', () => {
  mobilMenu.classList.toggle('hidden');
});
